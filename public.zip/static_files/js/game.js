const UNSTARTED = 0;
		const RUNNING = 1;
		const FINISHED = 2;

		const CORRECT = 0;
		const INCORRECT = 1;
		const GUESSED = 2;

		var ar_button_list = Array.from( document.querySelectorAll('.questions > li') );

		ar_button_list.forEach( function(elem){
			elem.addEventListener("click", on_game_event);
		});

		function on_game_event(e) {
			if (game_object.lifecycle === RUNNING) {

				var guess_res = process_guess(this);

				if (guess_res===CORRECT) {
					win();
				} else if (guess_res===INCORRECT) {
					if (game_object.attempts_remaining==0) {
						lose();
					}
				}
			}
		}

		function process_guess(li) {
			var already_guessed = li.getAttribute('guessed');
			
			if (already_guessed=='true') {
				return GUESSED;
			} else {
				li.setAttribute('guessed',true);				// indicate this choice has been guessed

				game_object.attempts_remaining--;
				update_moves();

				var choice = li.getAttribute('my_data');

				if (game_object.correct_answer==choice) {
					li.style['background-color'] = "green";		//correct
					displayQs();
					return CORRECT;
				} else {
					li.style['background-color'] = "red"		//incorrect
					return INCORRECT;
				}

			}
		}

		function win() {
			document.getElementById('response').innerHTML="WIN";
			end_game();
		}

		function lose() {
			document.getElementById('response').innerHTML="LOSE";
			end_game();
		}

		function update_moves() {
			var m = document.getElementById('moves');
			m.innerHTML = game_object.attempts_remaining;
		}

		/* THIS IS THE OBJECT THAT CONTROLS THE GAME STATE */

		var game_object = {
			'lifecycle' : UNSTARTED,
			'correct_answer' : null,
			'attempts_remaining' : null
		};


		/* GAME LIFECYCLE TRANSITION METHODS */

		function init_game() {
		    console.log("init before if");
			if (game_object.lifecycle === UNSTARTED) {
				console.log("init_game");
				
				// adjust lifecycle
				game_object.lifecycle = RUNNING;

                displayQs();
                
				// change start button display
				var b = document.getElementById('btn_start');
				b.style.backgroundColor = "#4E7EFF";

				// choose a right answer
				var choices = ar_button_list.map( function(elem) {
					elem.setAttribute('guessed',false);				// indicate this choice has been guessed
	   				return elem.getAttribute('my_data');
				})
				var choice_number = Math.floor( choices.length * Math.random() );
				game_object.correct_answer = choices[choice_number];
				
				// set remaining moves
				game_object.attempts_remaining = 3;

				update_moves();

				// log the right answer
				console.log( game_object.correct_answer )
			}

		}
		function end_game() {

			// make the start button appear inactive
			var b = document.getElementById('btn_start');
			b.style.backgroundColor = "#BBB";

			// make the reset button appear active
			var r = document.getElementById('btn_reset');
			r.style.backgroundColor = "#FF75FF"

			game_object.lifecycle = FINISHED;
		}


		function reset_game() {

			if (game_object.lifecycle === FINISHED) {

				// clear all the buttons
				ar_button_list.forEach( function(elem){
					elem.style.backgroundColor="#D3D3D3"
				});
				// clear the response
				document.getElementById('response').innerHTML="";

				// make the start button green
				var b = document.getElementById('btn_start');
				b.style.backgroundColor = "green";
				
				// make the reset button grey
				var r = document.getElementById('btn_reset');
				r.style.backgroundColor = "#BBB"

				// reset the game state
				game_object.lifecycle = UNSTARTED;
			}
		}
		
	

function displayQs() {
    console.log("displayqs");
    var ajax_params = {
        'url'     : "https://user.tjhsst.edu/2023awang/gameqs",
        'type'    : "get",
        'success' : displayQuestions    // the name of the callback function to call
    }
    // run AJAX function 
    $.ajax( ajax_params )
}

function displayQuestions(responseObject) {
    var q = responseObject.qanda[0].question;
    var tempHtml = `<div class="questions">
            <p>${q}</p>                
        </div>` ;
    document.getElementById('f_questions').innerHTML = tempHtml;
    
}