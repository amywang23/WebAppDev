var min = 0;
var sec = 0;
var stopwatch = document.getElementById("stopwatch");
var timelimit = 30;

function stopTimer() {
    clearInterval(stopwatch);
    stopwatch = null;
}

function cycle(){
    min = parseInt(min);
    sec = parseInt(sec);
    
    sec += 1;
    
    if(sec === 30) {
        stopTimer();
    }
    
    if(sec === 60) {
        min += 1;
        sec = 0;
    }
    
    if(sec < 10) {
        sec = '0' + sec;
    }
    
    if(min < 10) {
        min = '0' + min;
    }
    
    document.getElementById('stopwatch').innerHTML = min + ':' + sec;
}

function startTimer(){
    stopwatch = setInterval(cycle, 1000);
}