#!/usr/bin/nodejs


// -------------- load packages -------------- //
var express = require('express');
var app = express();

var hbs = require('hbs')
app.set('view engine','hbs')

// -------------- express 'get' handlers -------------- //

app.get('/', function(req,res) {

    console.log('request initiated')

    setTimeout( function() {
        console.log('request completed')
        res.render('index')
    }, 4000);

})




// -------------- listener -------------- //
// // The listener is what keeps node 'alive.' 

var listener = app.listen(process.env.PORT || 8080, process.env.HOST || "0.0.0.0", function() {
    console.log("Express server started");
});