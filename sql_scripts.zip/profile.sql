DROP TABLE IF EXISTS profiles;

CREATE TABLE profiles(fullname VARCHAR(100), nickname VARCHAR(100), PRIMARY KEY(fullname));