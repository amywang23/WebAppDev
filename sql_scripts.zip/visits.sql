DROP TABLE IF EXISTS pagevisits;

CREATE TABLE pagevisits (count INT);
INSERT INTO pagevisits (count) VALUES (0);